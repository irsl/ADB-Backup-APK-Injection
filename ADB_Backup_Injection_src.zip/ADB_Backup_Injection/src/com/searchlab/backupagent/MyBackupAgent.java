package com.searchlab.backupagent;

import java.io.File;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.lang.reflect.Method;

import android.app.backup.BackupAgent;
import android.app.backup.BackupDataInput;
import android.app.backup.BackupDataOutput;
import android.app.backup.FullBackupDataOutput;
import android.content.res.AssetManager;
import android.os.ParcelFileDescriptor;
import android.util.Log;


public class MyBackupAgent extends BackupAgent {

	private void copyAssets() {
	    AssetManager assetManager = getAssets();
	    String[] files = null;
	    try {
	        files = assetManager.list("");
	    } catch (IOException e) {
	        Log.e("tag", "Failed to get asset file list.", e);
	    }
	    for(String filename : files) {
	        InputStream in = null;
	        OutputStream out = null;
	        try {
	          in = assetManager.open(filename);
	          File outFile = new File(getFilesDir(), filename);
	          out = new FileOutputStream(outFile);
	          copyFile(in, out);
	          in.close();
	          in = null;
	          out.flush();
	          out.close();
	          out = null;
	        } catch(IOException e) {
	            Log.e("tag", "Failed to copy asset file: " + filename, e);
	        }       
	    }
	}
	private void copyFile(InputStream in, OutputStream out) throws IOException {
	    byte[] buffer = new byte[1024];
	    int read;
	    while((read = in.read(buffer)) != -1){
	      out.write(buffer, 0, read);
	    }
	}
	
	@Override
	public void onCreate() {
		super.onCreate();
		
		  copyAssets();
		   
		  Log.v("MYBACKUP", "Assets extracted");

	}
	
	@Override
	public void onFullBackup(android.app.backup.FullBackupDataOutput data) throws IOException {
		Log.v("MYBACKUP", "My Backup Agent in onFullBackup!");
		
		
		
		
	  Log.v("MYBACKUP", "My Backup Agent in onFullBackup!");
	    
	  String packageName = "com.searchlab.wifitest"; 
	  
	  Method backupToTar;
	  Method getData;
		try {
			Class<?> fullbackupClass = Class.forName("android.app.backup.FullBackup");

			Class<?> backupDataOutputClass = Class.forName("android.app.backup.BackupDataOutput");
			
			backupToTar = fullbackupClass.getDeclaredMethod("backupToTar", String.class, String.class, String.class, String.class, String.class, backupDataOutputClass);
			backupToTar.setAccessible(true);		
			
			getData = FullBackupDataOutput.class.getDeclaredMethod("getData");
			 getData.setAccessible(true);
			 Object backupData = getData.invoke(data);
			
			 
			backupToTar.invoke(null, packageName, null, null, getFilesDir().toString(), getFilesDir()+"/_manifest", backupData);
			backupToTar.invoke(null, packageName, "a", null, getFilesDir().toString(),getFilesDir()+"/com.searchlab.wifitest-1.apk", backupData);
		    
			Log.v("MYBACKUP", "backuptotar invoked!");
			
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	  
	}
	
	@Override
	public void onBackup(ParcelFileDescriptor arg0, BackupDataOutput arg1,
			ParcelFileDescriptor arg2) throws IOException {
		Log.e("MYBACKUP", "My Backup Agent in onBackup!");
	}

	@Override
	public void onRestore(BackupDataInput data, int appVersionCode,
			ParcelFileDescriptor newState) throws IOException {
		
		Log.e("MYBACKUP", "My Backup Agent in onRestore!");
	}

	
	
}
