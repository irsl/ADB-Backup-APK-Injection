package com.searchlab.backupagent;

import com.searchlab.backupagenttest.R;

import android.app.Activity;
import android.os.Bundle;
import android.widget.TextView;

public class MainActivity extends Activity {

    
	TextView tv;
	int scroll_amount;
	
	private void addMessage(String msg) {
	    tv.append(msg + "\n");
	    scroll_amount += tv.getLineHeight();
        tv.scrollTo(0, scroll_amount);
	}
	
	
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

		tv = (TextView) findViewById(R.id.txtLog);
		tv.setFocusable(true);
		
		addMessage("I am "+getPackageName()+".");
		addMessage("I look like an innocent application, but if you backup and restore me via adb...");       
               
    }
}
